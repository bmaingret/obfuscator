"""Define an entry point when running `python -m obfuscator`"""

from obfuscator.cli import app  # pragma: no cover

app(prog_name="bmaingret-obfuscator")  # pragma: no cover

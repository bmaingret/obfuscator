# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['obfuscator']

package_data = \
{'': ['*'],
 'obfuscator': ['data/c_function_examples/*',
                'data/fake_libc_include/*',
                'data/fake_libc_include/X11/*',
                'data/fake_libc_include/arpa/*',
                'data/fake_libc_include/asm-generic/*',
                'data/fake_libc_include/linux/*',
                'data/fake_libc_include/mir_toolkit/*',
                'data/fake_libc_include/net/*',
                'data/fake_libc_include/netinet/*',
                'data/fake_libc_include/openssl/*',
                'data/fake_libc_include/sys/*',
                'data/fake_libc_include/xcb/*']}

install_requires = \
['cffi>=1.15.0,<2.0.0',
 'pycparserext>=2021.1,<2022.0',
 'typer[all]>=0.3.2,<0.4.0']

entry_points = \
{'console_scripts': ['bmaingret-obfuscator = obfuscator.cli:app']}

setup_kwargs = {
    'name': 'bmaingret-obfuscator',
    'version': '0.1.0',
    'description': 'Basic C Obfuscator',
    'long_description': "# obfuscator: obfuscating C source code with Python - Proof of concept\n\n## Requirements\n\nIn addition to Python toolings:\n\n* gcc\n\nAnd to fully use the makefile:\n\n* pyenv\n* curl\n* zip/unzip\n* sed\n* poetry\n* and obvisouly make\n\nTested with `Python 3.9.4`. We recommend using `pyenv` to install an adequate Python version.\n\n\n## Install\n\nEither install the wheel from the `dist` folder:\n\n```console\n$ python -m pip install bmaingret_obfuscator-0.1.0-py3-none-any.whl\n```\n\nOr install locally:\n\n```console\n$ python -m pip install .\n```\n\nOr run it from source and simply install dependencies:\n\n```\n$ python -m pip install -r requirements.txt\n```\n\n## Usage\n\nIf the package was installed, the `bmaingret-obfuscator` should be available (you might have to reload your shell):\n\n```\n$ exec $SHELL\n$ bmaingret-obfuscator --help\n$ bmaingret-obfuscator obfuscate --help\n```\n\nElse run it as a standard python module (Note the difference in name. Here we locate the module name, whereas previously we used the package name to prevent name clashes if installed on a system.):\n\n```\n$ python -m obfuscator --help\n$ python -m obfuscator demo --help\n```\n\nThey are two main commands:\n\n* `obfuscate`: obfuscate source file located at the path passed as an argument\n* `demo`: run obfuscator on example source files\n\nFull documentation (in addition to running the command with `--help`) can be found in [CLI_DOCS.md](CLI_DOCS.md). Note that if running from source, you'll have to replace `bmaingret-obfuscator` by `obfuscator`.\n\n## Tests\n\nTests are written with `pytest` and can be run against the source code:\n\n```\n$ python -m pip install requirements-dev.txt\n$ make test\n$ make cov\ncoverage report\nName                       Stmts   Miss  Cover   Missing\n--------------------------------------------------------\nobfuscator/__init__.py        18      0   100%\nobfuscator/__main__.py         0      0   100%\nobfuscator/cli.py             62      0   100%\nobfuscator/cparser.py         18      0   100%\nobfuscator/ctools.py          73      0   100%\nobfuscator/examples.py        10      0   100%\nobfuscator/techniques.py      44      0   100%\n--------------------------------------------------------\nTOTAL                        225      0   100%\n```\n\n## Makefile\n\nImportant note: the makefile is more used as a shortcut for multiple commands than its original intent. As such, and to prevent having  `pip install -r requirements-dev.txt` run each time we run tests, some dependencies are not reflected in the makefile. They should however be reflected in its documentation.\n\n```\n$ make\nAvailable rules:\n\nalint               Shortcut for autoformat and lint - Requires to have run make dev \nautoformat          Autoformat using black and isort - Requires to have run make dev \nbuild               Build Python wheel and sdist using Poetry \nclean               Delete all compiled Python files \ncli_docs            Generate typer application documentation - Requires to have run make dev \ncov                 Run test coverage - Requires to have run make dev \ndev                 Install development dependencies \ninit                Setup a Python environment for local development. \nlint                Lint pylint and bandit - Requires to have run make dev \nrequirements        Install Python Dependencies \nrequire_pyenv       Check pyenv and pyenv-virtualenv installations \ntest                Run tests - Requires to have run make dev \nzip                 Zip the content of the repository \n```\n\n## Lint and autoformat\n\nConfigurations can be found in `pyproject.toml`. Using [Google](https://github.com/google/styleguide/blob/gh-pages/pylintrc) `.pylintrc` with some tweaks (c.f. makefile `dev`).\n\n* autoflake\n* black\n* isort\n* bandit\n\n```\n$ make lint\n[---]\n-----------------------------------\nYour code has been rated at 9.67/10\n```\n",
    'author': 'Baptiste Maingret',
    'author_email': 'baptiste.maingret@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
